import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Pressable, Platform } from 'react-native';
import * as Brightness from 'expo-brightness';
import Slider from '@react-native-community/slider';
import Animated, { SlideInUp, SlideOutDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '@/context/ThemeContext';
import { type ContentColumnWidth, type MarginPreset } from '@/types/theme';
import { ThemedText } from '@/components/ui/ThemedText';
import { PressableScale } from '@/components/ui/PressableScale';
import { X, Sun, Columns, AlignHorizontalSpaceAround, Sparkles, Monitor } from 'lucide-react-native';

type Props = {
  visible: boolean;
  onClose: () => void;
};

const MARGIN_OPTIONS: { id: MarginPreset; label: string }[] = [
  { id: 'narrow', label: 'Narrow' },
  { id: 'medium', label: 'Medium' },
  { id: 'wide', label: 'Wide' },
];

const COLUMN_OPTIONS: { id: ContentColumnWidth; label: string }[] = [
  { id: null, label: 'Full' },
  { id: 560, label: 'Compact' },
  { id: 640, label: 'Standard' },
  { id: 720, label: 'Comfort' },
  { id: 840, label: 'Wide' },
];

export function ReaderLayoutPanel({ visible, onClose }: Props) {
  const insets = useSafeAreaInsets();
  const { currentTheme, readingSettings, setReadingSettings } = useTheme();
  const savedBrightness = useRef<number | null>(null);
  const [brightness, setBrightnessState] = useState(0.65);
  const [brightnessReady, setBrightnessReady] = useState(false);

  useEffect(() => {
    if (!visible || Platform.OS === 'web') return;
    let cancelled = false;
    (async () => {
      try {
        const ok = await Brightness.isAvailableAsync();
        if (!ok || cancelled) {
          setBrightnessReady(false);
          return;
        }
        await Brightness.requestPermissionsAsync().catch(() => null);
        const b = await Brightness.getBrightnessAsync();
        if (!cancelled) {
          savedBrightness.current = b;
          setBrightnessState(b);
          setBrightnessReady(true);
        }
      } catch {
        setBrightnessReady(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [visible]);

  const restoreBrightness = useCallback(async () => {
    if (Platform.OS === 'web') return;
    try {
      if (Platform.OS === 'android') {
        await Brightness.restoreSystemBrightnessAsync();
      } else if (savedBrightness.current != null) {
        await Brightness.setBrightnessAsync(savedBrightness.current);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!visible) restoreBrightness();
  }, [visible, restoreBrightness]);

  const onBrightnessChange = async (v: number) => {
    setBrightnessState(v);
    if (Platform.OS === 'web' || !brightnessReady) return;
    try {
      await Brightness.setBrightnessAsync(v);
    } catch {
      /* ignore */
    }
  };

  if (!visible) return null;

  return (
    <>
      <Pressable style={styles.overlay} onPress={onClose} />
      <Animated.View
        entering={SlideInUp.duration(250)}
        exiting={SlideOutDown.duration(200)}
        style={[
          styles.panel,
          {
            backgroundColor: currentTheme.cardBackground,
            paddingBottom: insets.bottom + 20,
            borderTopColor: currentTheme.secondaryText + '22',
          },
        ]}
      >
        <View style={[styles.handle, { backgroundColor: currentTheme.secondaryText + '40' }]} />
        <View style={styles.headerRow}>
          <View style={styles.headerTitle}>
            <Columns size={22} color={currentTheme.accent} />
            <ThemedText variant="primary" size="header" weight="bold">
              Layout & display
            </ThemedText>
            <ThemedText variant="secondary" size="caption">
              Similar to Koodo-style reading controls
            </ThemedText>
          </View>
          <PressableScale onPress={onClose} style={styles.closeBtn}>
            <X size={22} color={currentTheme.secondaryText} />
          </PressableScale>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionLabel}>
            <AlignHorizontalSpaceAround size={16} color={currentTheme.secondaryText} />
            <ThemedText variant="secondary" size="caption" weight="semibold">
              MARGINS
            </ThemedText>
          </View>
          <View style={styles.chipRow}>
            {MARGIN_OPTIONS.map(opt => {
              const active = readingSettings.marginPreset === opt.id;
              return (
                <PressableScale
                  key={opt.id}
                  onPress={() => setReadingSettings({ marginPreset: opt.id })}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: active ? currentTheme.accent + '22' : currentTheme.background,
                      borderColor: active ? currentTheme.accent : currentTheme.secondaryText + '30',
                    },
                  ]}
                >
                  <ThemedText variant={active ? 'accent' : 'primary'} size="caption" weight={active ? 'semibold' : 'regular'}>
                    {opt.label}
                  </ThemedText>
                </PressableScale>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionLabel}>
            <Columns size={16} color={currentTheme.secondaryText} />
            <ThemedText variant="secondary" size="caption" weight="semibold">
              COLUMN WIDTH
            </ThemedText>
          </View>
          <View style={styles.chipRowWrap}>
            {COLUMN_OPTIONS.map(opt => {
              const active = readingSettings.contentColumnWidth === opt.id;
              return (
                <PressableScale
                  key={String(opt.id)}
                  onPress={() => setReadingSettings({ contentColumnWidth: opt.id })}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: active ? currentTheme.accent + '22' : currentTheme.background,
                      borderColor: active ? currentTheme.accent : currentTheme.secondaryText + '30',
                    },
                  ]}
                >
                  <ThemedText variant={active ? 'accent' : 'primary'} size="caption" weight={active ? 'semibold' : 'regular'}>
                    {opt.label}
                  </ThemedText>
                </PressableScale>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <PressableScale
            onPress={() => setReadingSettings({ bionicReading: !readingSettings.bionicReading })}
            style={[
              styles.toggleRow,
              {
                backgroundColor: currentTheme.background,
                borderColor: readingSettings.bionicReading ? currentTheme.accent : currentTheme.secondaryText + '25',
              },
            ]}
          >
            <View style={styles.toggleLeft}>
              <Sparkles size={20} color={readingSettings.bionicReading ? currentTheme.accent : currentTheme.secondaryText} />
              <View>
                <ThemedText variant="primary" size="body" weight="semibold">
                  Bionic reading
                </ThemedText>
                <ThemedText variant="secondary" size="caption">
                  Emphasize the start of longer words
                </ThemedText>
              </View>
            </View>
            <View
              style={[
                styles.pill,
                { backgroundColor: readingSettings.bionicReading ? currentTheme.accent : currentTheme.secondaryText + '35' },
              ]}
            >
              <ThemedText size="caption" weight="bold" style={{ color: '#FFF' }}>
                {readingSettings.bionicReading ? 'ON' : 'OFF'}
              </ThemedText>
            </View>
          </PressableScale>
        </View>

        <View style={styles.section}>
          <PressableScale
            onPress={() => setReadingSettings({ keepScreenOn: !readingSettings.keepScreenOn })}
            style={[
              styles.toggleRow,
              {
                backgroundColor: currentTheme.background,
                borderColor: readingSettings.keepScreenOn ? currentTheme.accent : currentTheme.secondaryText + '25',
              },
            ]}
          >
            <View style={styles.toggleLeft}>
              <Monitor size={20} color={readingSettings.keepScreenOn ? currentTheme.accent : currentTheme.secondaryText} />
              <View>
                <ThemedText variant="primary" size="body" weight="semibold">
                  Keep screen on
                </ThemedText>
                <ThemedText variant="secondary" size="caption">
                  While this book is open
                </ThemedText>
              </View>
            </View>
            <View
              style={[
                styles.pill,
                { backgroundColor: readingSettings.keepScreenOn ? currentTheme.accent : currentTheme.secondaryText + '35' },
              ]}
            >
              <ThemedText size="caption" weight="bold" style={{ color: '#FFF' }}>
                {readingSettings.keepScreenOn ? 'ON' : 'OFF'}
              </ThemedText>
            </View>
          </PressableScale>
        </View>

        {Platform.OS !== 'web' && (
          <View style={styles.section}>
            <View style={styles.sectionLabel}>
              <Sun size={16} color={currentTheme.secondaryText} />
              <ThemedText variant="secondary" size="caption" weight="semibold">
                SCREEN BRIGHTNESS
              </ThemedText>
            </View>
            {!brightnessReady ? (
              <ThemedText variant="secondary" size="caption" style={{ marginTop: 6 }}>
                Grant brightness permission in system settings to adjust from here.
              </ThemedText>
            ) : (
              <Slider
                style={styles.slider}
                minimumValue={0.15}
                maximumValue={1}
                value={brightness}
                onValueChange={onBrightnessChange}
                minimumTrackTintColor={currentTheme.accent}
                maximumTrackTintColor={currentTheme.secondaryText + '35'}
                thumbTintColor={currentTheme.accent}
              />
            )}
          </View>
        )}
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.45)',
    zIndex: 400,
  },
  panel: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 10,
    zIndex: 410,
    borderTopWidth: StyleSheet.hairlineWidth,
    maxHeight: '78%',
  },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginBottom: 14 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 },
  headerTitle: { flex: 1, gap: 4 },
  closeBtn: { padding: 6 },
  section: { marginBottom: 18 },
  sectionLabel: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  chipRow: { flexDirection: 'row', gap: 8 },
  chipRowWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1.5,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14,
    borderRadius: 14,
    borderWidth: 1.5,
  },
  toggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1, paddingRight: 8 },
  pill: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  slider: { width: '100%', height: 40, marginTop: 4 },
});
