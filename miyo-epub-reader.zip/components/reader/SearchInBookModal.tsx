import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  StyleSheet,
  Modal,
  Pressable,
  TextInput,
  FlatList,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import Animated, {
  FadeIn,
  SlideInUp,
  SlideOutDown,
} from 'react-native-reanimated';
import { Search, X, ChevronUp, ChevronDown } from 'lucide-react-native';
import { useTheme } from '@/context/ThemeContext';
import { ThemedText } from '@/components/ui/ThemedText';
import { PressableScale } from '@/components/ui/PressableScale';
import { EpubChapter } from '@/utils/epub-parser';

interface SearchResult {
  chapterIndex: number;
  chapterTitle: string;
  excerpt: string;
  matchIndex: number;
  matchStart: number;
  matchEnd: number;
}

interface SearchInBookModalProps {
  visible: boolean;
  onClose: () => void;
  chapters: EpubChapter[];
  currentChapterIndex: number;
  onGoToChapter: (index: number, searchTerm: string) => void;
}

function stripHtml(html: string): string {
  return html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function searchInChapters(
  chapters: EpubChapter[],
  query: string
): SearchResult[] {
  if (!query.trim() || query.length < 2) return [];
  const results: SearchResult[] = [];
  const lowerQuery = query.toLowerCase();
  const CONTEXT_CHARS = 80;

  for (let ci = 0; ci < chapters.length; ci++) {
    const chapter = chapters[ci];
    const text = stripHtml(chapter.content);
    const lowerText = text.toLowerCase();

    let searchIdx = 0;
    let matchCount = 0;
    while (matchCount < 5) {
      const idx = lowerText.indexOf(lowerQuery, searchIdx);
      if (idx === -1) break;

      const start = Math.max(0, idx - CONTEXT_CHARS);
      const end = Math.min(text.length, idx + query.length + CONTEXT_CHARS);
      const excerpt =
        (start > 0 ? '…' : '') +
        text.slice(start, end) +
        (end < text.length ? '…' : '');

      results.push({
        chapterIndex: ci,
        chapterTitle: chapter.title || `Chapter ${ci + 1}`,
        excerpt,
        matchIndex: matchCount,
        matchStart: idx - start + (start > 0 ? 1 : 0),
        matchEnd: idx - start + (start > 0 ? 1 : 0) + query.length,
      });

      searchIdx = idx + 1;
      matchCount++;
    }

    if (results.length >= 50) break;
  }

  return results;
}

export function SearchInBookModal({
  visible,
  onClose,
  chapters,
  currentChapterIndex,
  onGoToChapter,
}: SearchInBookModalProps) {
  const { currentTheme } = useTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleSearch = useCallback(
    (text: string) => {
      setQuery(text);
      if (searchTimeout.current) clearTimeout(searchTimeout.current);
      if (!text.trim() || text.length < 2) {
        setResults([]);
        return;
      }
      setIsSearching(true);
      searchTimeout.current = setTimeout(() => {
        const found = searchInChapters(chapters, text);
        setResults(found);
        setIsSearching(false);
      }, 300);
    },
    [chapters]
  );

  const handleSelectResult = (result: SearchResult) => {
    onGoToChapter(result.chapterIndex, query);
    onClose();
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
  };

  const isDark = currentTheme.isDark;

  const renderResult = ({ item, index }: { item: SearchResult; index: number }) => {
    const excerptBefore = item.excerpt.slice(0, item.matchStart);
    const excerptMatch = item.excerpt.slice(item.matchStart, item.matchEnd);
    const excerptAfter = item.excerpt.slice(item.matchEnd);
    const isCurrentChapter = item.chapterIndex === currentChapterIndex;

    return (
      <PressableScale
        onPress={() => handleSelectResult(item)}
        style={[
          styles.resultItem,
          {
            backgroundColor: isCurrentChapter
              ? currentTheme.accent + '10'
              : currentTheme.background,
            borderColor: isCurrentChapter
              ? currentTheme.accent + '30'
              : currentTheme.secondaryText + '15',
          },
        ]}
      >
        <View style={styles.resultHeader}>
          <ThemedText
            style={[styles.resultChapter, { color: currentTheme.accent }]}
            numberOfLines={1}
          >
            {item.chapterTitle}
          </ThemedText>
          {isCurrentChapter && (
            <View style={[styles.currentBadge, { backgroundColor: currentTheme.accent + '20' }]}>
              <ThemedText style={[styles.currentBadgeText, { color: currentTheme.accent }]}>
                Current
              </ThemedText>
            </View>
          )}
        </View>
        <ThemedText style={[styles.resultExcerpt, { color: currentTheme.text }]} numberOfLines={3}>
          {excerptBefore}
          <ThemedText style={[styles.resultMatch, { backgroundColor: currentTheme.accent + '35', color: currentTheme.text }]}>
            {excerptMatch}
          </ThemedText>
          {excerptAfter}
        </ThemedText>
      </PressableScale>
    );
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <Pressable style={styles.backdrop} onPress={onClose} />
        <Animated.View
          entering={SlideInUp.duration(250)}
          exiting={SlideOutDown.duration(200)}
          style={[
            styles.card,
            {
              backgroundColor: currentTheme.cardBackground,
              borderTopColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)',
            },
          ]}
        >
          {/* Handle */}
          <View style={[styles.handle, { backgroundColor: currentTheme.secondaryText + '40' }]} />

          {/* Header */}
          <View style={styles.header}>
            <ThemedText variant="primary" size="header" weight="bold">
              Search in Book
            </ThemedText>
            <PressableScale onPress={onClose} style={styles.closeBtn}>
              <X size={20} color={currentTheme.secondaryText} />
            </PressableScale>
          </View>

          {/* Search input */}
          <View
            style={[
              styles.searchInputContainer,
              {
                backgroundColor: isDark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.05)',
                borderColor: isDark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.08)',
              },
            ]}
          >
            <Search size={18} color={currentTheme.secondaryText} strokeWidth={2} />
            <TextInput
              style={[styles.searchInput, { color: currentTheme.text }]}
              placeholder="Search for words, phrases…"
              placeholderTextColor={currentTheme.secondaryText + '80'}
              value={query}
              onChangeText={handleSearch}
              autoFocus
              returnKeyType="search"
            />
            {query.length > 0 && (
              <Pressable onPress={clearSearch} style={styles.clearBtn}>
                <X size={16} color={currentTheme.secondaryText} />
              </Pressable>
            )}
          </View>

          {/* Results count */}
          {query.length >= 2 && (
            <View style={styles.resultsMeta}>
              {isSearching ? (
                <ThemedText variant="secondary" size="caption">Searching…</ThemedText>
              ) : (
                <ThemedText variant="secondary" size="caption">
                  {results.length === 0
                    ? 'No results found'
                    : `${results.length}${results.length >= 50 ? '+' : ''} result${results.length !== 1 ? 's' : ''}`}
                </ThemedText>
              )}
            </View>
          )}

          {/* Results list */}
          <FlatList
            data={results}
            renderItem={renderResult}
            keyExtractor={(_, idx) => idx.toString()}
            style={styles.resultsList}
            contentContainerStyle={styles.resultsContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              query.length >= 2 && !isSearching ? (
                <View style={styles.emptyState}>
                  <ThemedText variant="secondary" size="body" style={{ textAlign: 'center' }}>
                    No matches for "{query}"
                  </ThemedText>
                  <ThemedText variant="secondary" size="caption" style={{ textAlign: 'center', marginTop: 4 }}>
                    Try different keywords
                  </ThemedText>
                </View>
              ) : null
            }
          />
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  card: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderTopWidth: 1,
    paddingTop: 12,
    paddingHorizontal: 20,
    paddingBottom: Platform.OS === 'ios' ? 36 : 24,
    maxHeight: '85%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 20,
  },
  handle: {
    width: 38,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  closeBtn: {
    padding: 4,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 11,
    gap: 10,
    marginBottom: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    padding: 0,
  },
  clearBtn: {
    padding: 2,
  },
  resultsMeta: {
    marginBottom: 10,
  },
  resultsList: {
    flex: 1,
  },
  resultsContent: {
    gap: 8,
    paddingBottom: 16,
  },
  resultItem: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 6,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  resultChapter: {
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
    letterSpacing: 0.3,
  },
  currentBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  currentBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.4,
  },
  resultExcerpt: {
    fontSize: 14,
    lineHeight: 20,
  },
  resultMatch: {
    fontWeight: '700',
    borderRadius: 3,
  },
  emptyState: {
    paddingVertical: 40,
    alignItems: 'center',
    gap: 6,
  },
});
