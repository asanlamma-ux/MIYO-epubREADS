import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Modal,
  Pressable,
  TextInput,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import Animated, { SlideInUp, SlideOutDown } from 'react-native-reanimated';
import { useTheme } from '@/context/ThemeContext';
import { useTerms } from '@/context/TermsContext';
import { ThemedText } from '@/components/ui/ThemedText';
import { PressableScale } from '@/components/ui/PressableScale';
import { X, Plus, Check } from 'lucide-react-native';

interface AddTermModalProps {
  visible: boolean;
  /** Pre-filled original text (from reader selection) */
  initialText?: string;
  /** Pre-selected group ID */
  groupId?: string;
  onClose: () => void;
}

export function AddTermModal({ visible, initialText, groupId, onClose }: AddTermModalProps) {
  const { currentTheme } = useTheme();
  const { termGroups, addTerm, createGroup } = useTerms();

  const [originalText, setOriginalText] = useState('');
  const [correctedText, setCorrectedText] = useState('');
  const [contextText, setContextText] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');

  useEffect(() => {
    if (visible) {
      setOriginalText(initialText ?? '');
      setCorrectedText('');
      setContextText('');
      setSelectedGroupId(groupId ?? (termGroups.length > 0 ? termGroups[0].id : null));
      setShowCreateGroup(false);
      setNewGroupName('');
    }
  }, [visible, initialText, groupId]);

  const isDark = currentTheme.isDark;

  const handleSave = async () => {
    if (!originalText.trim() || !correctedText.trim()) return;

    let targetGroupId = selectedGroupId;

    // Create new group if needed
    if (showCreateGroup && newGroupName.trim()) {
      const newGroup = await createGroup(newGroupName.trim());
      targetGroupId = newGroup.id;
    }

    if (!targetGroupId) return;

    await addTerm(targetGroupId, originalText.trim(), correctedText.trim(), contextText.trim() || undefined);
    onClose();
  };

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent>
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable style={styles.backdrop} onPress={onClose} />
        <Animated.View
          entering={SlideInUp.duration(250)}
          exiting={SlideOutDown.duration(200)}
          style={[
            styles.card,
            {
              backgroundColor: currentTheme.cardBackground,
              borderTopColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)',
            },
          ]}
        >
          {/* Header */}
          <View style={styles.header}>
            <ThemedText variant="primary" size="header" weight="bold">Add Term</ThemedText>
            <PressableScale onPress={onClose}>
              <X size={22} color={currentTheme.secondaryText} />
            </PressableScale>
          </View>

          <ScrollView showsVerticalScrollIndicator={false} style={styles.fields}>
            {/* Original */}
            <ThemedText variant="secondary" size="caption" weight="medium" style={styles.label}>
              ORIGINAL TEXT
            </ThemedText>
            <TextInput
              style={[styles.input, { color: currentTheme.text, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)', borderColor: currentTheme.secondaryText + '25' }]}
              value={originalText}
              onChangeText={setOriginalText}
              placeholder="Word or phrase as it appears"
              placeholderTextColor={currentTheme.secondaryText + '80'}
              multiline
            />

            {/* Corrected */}
            <ThemedText variant="secondary" size="caption" weight="medium" style={styles.label}>
              CORRECTED TRANSLATION
            </ThemedText>
            <TextInput
              style={[styles.input, { color: currentTheme.text, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)', borderColor: currentTheme.secondaryText + '25' }]}
              value={correctedText}
              onChangeText={setCorrectedText}
              placeholder="Your preferred translation"
              placeholderTextColor={currentTheme.secondaryText + '80'}
              multiline
            />

            {/* Context */}
            <ThemedText variant="secondary" size="caption" weight="medium" style={styles.label}>
              CONTEXT (OPTIONAL)
            </ThemedText>
            <TextInput
              style={[styles.input, { color: currentTheme.text, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)', borderColor: currentTheme.secondaryText + '25' }]}
              value={contextText}
              onChangeText={setContextText}
              placeholder="Example sentence or note"
              placeholderTextColor={currentTheme.secondaryText + '80'}
            />

            {/* Group Selector */}
            <ThemedText variant="secondary" size="caption" weight="medium" style={styles.label}>
              TERM GROUP
            </ThemedText>

            {!showCreateGroup ? (
              <>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.groupChips}>
                  {termGroups.map((g) => {
                    const isActive = selectedGroupId === g.id;
                    return (
                      <PressableScale
                        key={g.id}
                        onPress={() => setSelectedGroupId(g.id)}
                        style={[
                          styles.groupChip,
                          {
                            backgroundColor: isActive ? currentTheme.accent + '20' : currentTheme.background,
                            borderColor: isActive ? currentTheme.accent : currentTheme.secondaryText + '25',
                          },
                        ]}
                      >
                        <ThemedText
                          variant={isActive ? 'accent' : 'secondary'}
                          size="caption"
                          weight={isActive ? 'semibold' : 'regular'}
                        >
                          {g.name}
                        </ThemedText>
                      </PressableScale>
                    );
                  })}
                  <PressableScale
                    onPress={() => setShowCreateGroup(true)}
                    style={[styles.groupChip, { backgroundColor: currentTheme.background, borderColor: currentTheme.accent + '40', borderStyle: 'dashed' }]}
                  >
                    <Plus size={14} color={currentTheme.accent} />
                    <ThemedText variant="accent" size="caption" weight="medium">New Group</ThemedText>
                  </PressableScale>
                </ScrollView>
              </>
            ) : (
              <View style={styles.newGroupRow}>
                <TextInput
                  style={[styles.input, { flex: 1, color: currentTheme.text, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)', borderColor: currentTheme.accent }]}
                  value={newGroupName}
                  onChangeText={setNewGroupName}
                  placeholder="New group name"
                  placeholderTextColor={currentTheme.secondaryText + '80'}
                  autoFocus
                />
                <PressableScale onPress={() => setShowCreateGroup(false)} style={{ padding: 8 }}>
                  <X size={18} color={currentTheme.secondaryText} />
                </PressableScale>
              </View>
            )}
          </ScrollView>

          {/* Save */}
          <PressableScale
            onPress={handleSave}
            style={[styles.saveBtn, { backgroundColor: currentTheme.accent, opacity: (!originalText.trim() || !correctedText.trim()) ? 0.5 : 1 }]}
            disabled={!originalText.trim() || !correctedText.trim()}
          >
            <Check size={18} color="#FFFFFF" />
            <ThemedText style={{ color: '#FFFFFF', fontWeight: '700', fontSize: 15 }}>Save Term</ThemedText>
          </PressableScale>
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  card: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderTopWidth: 1,
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 24,
    maxHeight: '85%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  fields: {
    marginBottom: 16,
  },
  label: {
    letterSpacing: 0.8,
    marginBottom: 8,
    marginTop: 14,
  },
  input: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    fontSize: 15,
    lineHeight: 22,
  },
  groupChips: {
    gap: 8,
    paddingVertical: 2,
  },
  groupChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
  },
  newGroupRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
});
